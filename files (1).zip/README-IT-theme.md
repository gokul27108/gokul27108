<div align="center">

![Header](https://capsule-render.vercel.app/api?type=waving&height=220&color=0:0d1117,45:0f3460,100:00c9a7&text=Gokul%20M&fontColor=ffffff&fontSize=64&fontAlignY=38&desc=Java%20%7C%20MERN%20Stack%20%7C%20Problem%20Solver&descSize=20&descAlignY=60&animation=twinkling)

<img src="https://raw.githubusercontent.com/gokul27108/gokul27108/main/profile-it.png" alt="Gokul M" width="190">

[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&weight=600&size=22&duration=2600&pause=900&color=00FF9C&center=true&vCenter=true&width=640&lines=%3E+whoami;Gokul+M+%7C+Java+and+MERN+Stack+Developer;%3E+building+full-stack+apps+from+database+to+screen;%3E+open_to_work+%3D+true+%F0%9F%9A%80)](https://github.com/gokul27108)

[![GitHub](https://img.shields.io/badge/GitHub-gokul27108-181717?style=for-the-badge&logo=github&logoColor=white)](https://github.com/gokul27108)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Gokul%20M-0A66C2?style=for-the-badge&logo=linkedin&logoColor=white)](https://www.linkedin.com/in/gokul-m-a4b08b314/)
[![LeetCode](https://img.shields.io/badge/LeetCode-gokul__5048-FFA116?style=for-the-badge&logo=leetcode&logoColor=white)](https://leetcode.com/u/gokul_5048/)
[![Email](https://img.shields.io/badge/Email-Contact%20Me-00C9A7?style=for-the-badge&logo=gmail&logoColor=white)](mailto:gokulmathiyalagan27@gmail.com)

![Open to work](https://img.shields.io/badge/Open%20to-Entry--level%20roles-2ea44f?style=flat-square)
![B.Tech IT](https://img.shields.io/badge/B.Tech%20IT-CGPA%208.14-00C9A7?style=flat-square)
![Internship](https://img.shields.io/badge/Infosys-Springboard%20Intern-0F3460?style=flat-square)
![Location](https://img.shields.io/badge/Location-Namakkal%2C%20Tamil%20Nadu-orange?style=flat-square)

</div>

---

## 💻 About Me (as code)

```java
public class GokulM {
    String role       = "Java and MERN Stack Developer";
    String education  = "B.Tech IT, V.S.B. Engineering College (2023 - 2027)";
    double cgpa       = 8.14;
    String[] stack    = {"Java", "JavaScript", "React", "Node.js", "Express", "MongoDB", "MySQL"};
    String practice   = "LeetCode: gokul_5048";
    boolean openToWork = true;
    String goal       = "Entry-level software development role";
}
```

| | |
|---|---|
| 🎓 **Education** | B.Tech IT, V.S.B. Engineering College, Karur (Anna University), 2023 – 2027, **CGPA 8.14** |
| 💼 **Experience** | Infosys Springboard Internship 6.0, Enmlitiz Technology web development internship |
| 🛠️ **Core stack** | Java, JavaScript, React.js, Node.js, Express.js, MongoDB, MySQL |
| 🧩 **Practice** | Data structures and problem solving on [LeetCode](https://leetcode.com/u/gokul_5048/) |
| 🌱 **Improving** | Software development and interview skills |
| 🎯 **Looking for** | An entry-level software development role |

## 🛠️ Technical Skills

<div align="center">

![Skills](https://skillicons.dev/icons?i=java,js,python,html,css,react,nodejs,express,mongodb,mysql,git,github,aws&perline=7&theme=dark)

</div>

| Area | Technologies |
|------|--------------|
| **Programming** | `Java` `JavaScript` `Python` `SQL` |
| **Frontend** | `HTML` `CSS` `React.js` |
| **Backend** | `Node.js` `Express.js` `REST API` |
| **Databases** | `MySQL` `MongoDB` |
| **Cloud and tools** | `AWS (Cloud Practitioner Essentials)` `Git` `GitHub` |
| **Fundamentals** | `Object-Oriented Programming` `DBMS` `Data Structures` |

## 📌 Featured Projects

<table>
<tr>
<td width="50%" valign="top">

### 📜 Bulk Certificate Generator API
Generates certificates in bulk from structured input data.

- Validates every request before processing
- Creates PDF certificates
- Handles large batches efficiently

`REST API` `PDF generation` `Validation`

[**View repository**](https://github.com/gokul27108/bulk-certificate-generator-api-)

</td>
<td width="50%" valign="top">

### 🏛️ Government Scheme Identifier
Helps people find government schemes they qualify for.

- Matches users to schemes by eligibility
- Shows scheme details and how to apply
- Simple, easy-to-follow layout

`MongoDB` `Express.js` `React.js` `Node.js` `API`

</td>
</tr>
<tr>
<td width="50%" valign="top">

### 💬 Q&A Social Learning Platform
A Q&A site for programming, mathematics and technical topics.

- Voting-based answer validation
- Multilingual support
- Formatted equations and code snippets

`MongoDB` `Express.js` `React.js` `Node.js`

</td>
<td width="50%" valign="top">

### 🛡️ Fraud Detection and Transaction Simulation Engine
Built during my Infosys Springboard internship for digital banking.

- Transaction monitoring
- Fraud analysis
- Risk detection logic

`Java` `OOP`

</td>
</tr>
</table>

## 💼 Experience

**Infosys Springboard Internship 6.0** · Remote · *Dec 2025 – Feb 2026*
- Built a fraud detection and transaction simulation engine for digital banking in Java
- Worked on transaction monitoring, fraud analysis and risk detection logic

**Enmlitiz Technology, Salem** · Web Development Internship
- Worked on web development tasks and practical application development

## 🎓 Education

| Year | Qualification | Institution | Result |
|------|---------------|-------------|--------|
| 2023 – 2027 | B.Tech in Information Technology | V.S.B. Engineering College, Karur (Anna University) | CGPA 8.14 / 10 |
| March 2023 | Class XII (HSC) | Government Higher Secondary School, Kabilarmalai | 72.33% |
| March 2021 | Class X (SSLC) | Malar Matric Higher Secondary School, Paramathi | All pass |

## 📜 Certifications

| Certificate | Issuer / Result |
|-------------|-----------------|
| 🏅 Programming in Java | NPTEL · Elite + Silver, 78% |
| ☕ Java Foundation Certificate | Infosys |
| ☁️ AWS Cloud Practitioner Essentials | Amazon Web Services |
| 🤖 Introduction to Machine Learning | NPTEL |
| ☕ Java: Mastering the Fundamentals | Course |
| 🐍 Python Course for Beginners | Course |

## 📊 What I'm Working On

- 🌐 Full-stack MERN applications
- ☕ Java programming and OOP
- 🗄️ SQL and database design
- 🧮 Data structures and problem solving
- 🤖 AI-powered recruitment and developer tools

## 📈 GitHub Activity

<div align="center">

![Contribution graph](https://ghchart.rshah.org/00c9a7/gokul27108)

![GitHub stats](https://github-readme-stats.vercel.app/api?username=gokul27108&show_icons=true&count_private=true&theme=tokyonight&hide_border=true)
![Top languages](https://github-readme-stats.vercel.app/api/top-langs/?username=gokul27108&layout=compact&theme=tokyonight&hide_border=true)

[![LeetCode stats](https://leetcard.jacoblin.cool/gokul_5048?theme=dark&font=Fira%20Code&ext=heatmap)](https://leetcode.com/u/gokul_5048/)

</div>

## 🤝 Let's Work Together

I'm looking for an **entry-level software development role** where I can apply Java, the MERN stack and databases, and keep growing as an engineer. If you have an opening or a project, I'd love to hear from you.

<div align="center">

[![Email me](https://img.shields.io/badge/Email-gokulmathiyalagan27%40gmail.com-00C9A7?style=for-the-badge&logo=gmail&logoColor=white)](mailto:gokulmathiyalagan27@gmail.com)
[![Message on LinkedIn](https://img.shields.io/badge/Message%20me%20on-LinkedIn-0A66C2?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/gokul-m-a4b08b314/)

</div>

## 📫 Connect With Me

- GitHub: [@gokul27108](https://github.com/gokul27108)
- LinkedIn: [Gokul M](https://www.linkedin.com/in/gokul-m-a4b08b314/)
- LeetCode: [gokul_5048](https://leetcode.com/u/gokul_5048/)
- Email: gokulmathiyalagan27@gmail.com

<div align="center">

### ⭐ Thanks for visiting my profile!

![Footer](https://capsule-render.vercel.app/api?type=waving&height=120&color=0:00c9a7,55:0f3460,100:0d1117&section=footer)

</div>
