<div align="center">

<img src="./profile.jpg" alt="Gokul M" width="180" style="border-radius:50%;">

# Hi, I'm Gokul M 👋

### Java Developer | MERN Stack Developer | Problem Solver

Information Technology student from Namakkal, Tamil Nadu, India, building full-stack web applications and Java projects from the database to the screen.

[![GitHub](https://img.shields.io/badge/GitHub-gokul27108-181717?style=for-the-badge&logo=github)](https://github.com/gokul27108)
[![LinkedIn](https://img.shields.io/badge/LinkedIn-Gokul%20M-0A66C2?style=for-the-badge&logo=linkedin)](https://www.linkedin.com/in/gokul-m-a4b08b314/)
[![LeetCode](https://img.shields.io/badge/LeetCode-gokul__5048-FFA116?style=for-the-badge&logo=leetcode)](https://leetcode.com/u/gokul_5048/)
[![Email](https://img.shields.io/badge/Email-Contact%20Me-EA4335?style=for-the-badge&logo=gmail&logoColor=white)](mailto:gokulmathiyalagan27@gmail.com)

![Open to work](https://img.shields.io/badge/Open%20to-Entry--level%20roles-2ea44f?style=flat-square)
![Education](https://img.shields.io/badge/B.Tech%20IT-CGPA%208.14-2753d6?style=flat-square)
![Repos](https://img.shields.io/badge/Public%20repos-15-0e8a8c?style=flat-square)

</div>

---

## 🚀 About Me

- 🎓 B.Tech Information Technology student at V.S.B. Engineering College, Karur (Anna University), 2023 – 2027
- 💻 Interested in Java, MERN Stack and full-stack development
- 🧩 Enjoy solving programming and problem-solving challenges
- 🌱 Currently improving my software development and interview skills
- 🎯 Looking for an entry-level software development opportunity

## 🛠️ Technical Skills

### Programming
![Java](https://img.shields.io/badge/Java-ED8B00?style=for-the-badge&logo=openjdk&logoColor=white)
![JavaScript](https://img.shields.io/badge/JavaScript-F7DF1E?style=for-the-badge&logo=javascript&logoColor=black)
![Python](https://img.shields.io/badge/Python-3776AB?style=for-the-badge&logo=python&logoColor=white)
![SQL](https://img.shields.io/badge/SQL-4479A1?style=for-the-badge&logo=databricks&logoColor=white)

### Web Development
![HTML](https://img.shields.io/badge/HTML5-E34F26?style=for-the-badge&logo=html5&logoColor=white)
![CSS](https://img.shields.io/badge/CSS3-1572B6?style=for-the-badge&logo=css3&logoColor=white)
![React](https://img.shields.io/badge/React.js-20232A?style=for-the-badge&logo=react&logoColor=61DAFB)
![Node.js](https://img.shields.io/badge/Node.js-339933?style=for-the-badge&logo=nodedotjs&logoColor=white)
![Express](https://img.shields.io/badge/Express.js-000000?style=for-the-badge&logo=express&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-47A248?style=for-the-badge&logo=mongodb&logoColor=white)

### Databases
![MySQL](https://img.shields.io/badge/MySQL-4479A1?style=for-the-badge&logo=mysql&logoColor=white)
![MongoDB](https://img.shields.io/badge/MongoDB-47A248?style=for-the-badge&logo=mongodb&logoColor=white)

### Other
![Git](https://img.shields.io/badge/Git-F05032?style=for-the-badge&logo=git&logoColor=white)
![GitHub](https://img.shields.io/badge/GitHub-181717?style=for-the-badge&logo=github&logoColor=white)
![REST API](https://img.shields.io/badge/REST%20API-0e8a8c?style=for-the-badge)
![OOP](https://img.shields.io/badge/OOP-2753d6?style=for-the-badge)

## 📌 Featured Projects

### 📜 Bulk Certificate Generator API
A REST API that generates certificates in bulk from structured input data. It validates requests, creates PDFs, and processes large batches efficiently.

**Repository:** [bulk-certificate-generator-api-](https://github.com/gokul27108/bulk-certificate-generator-api-)

### 🏛️ Government Scheme Identifier
A full-stack web application that helps users find government schemes they are eligible for, and presents scheme details and application information in a simple, easy-to-follow format.

**Tech:** `MongoDB` `Express.js` `React.js` `Node.js` `API`

### 💬 Q&A Social Learning Platform
A web-based Q&A platform for programming, mathematics and technical topics, with voting-based answer validation, multilingual support, and rich formatting for equations and code snippets.

**Tech:** `MongoDB` `Express.js` `React.js` `Node.js`

### 🛡️ Fraud Detection and Transaction Simulation Engine
A Java-based engine for digital banking, built during my Infosys Springboard internship, covering transaction monitoring, fraud analysis and risk detection logic.

**Tech:** `Java`

## 🎓 Education

| Year | Qualification | Institution | Result |
|------|---------------|-------------|--------|
| 2023 – 2027 | B.Tech in Information Technology | V.S.B. Engineering College, Karur (Anna University) | CGPA 8.14 / 10 |
| March 2023 | Class XII (HSC) | Government Higher Secondary School, Kabilarmalai | 72.33% |
| March 2021 | Class X (SSLC) | Malar Matric Higher Secondary School, Paramathi | All pass |

## 📜 Certifications & Learning

- NPTEL Programming in Java — Elite + Silver, 78%
- Infosys Java Foundation Certificate
- NPTEL Introduction to Machine Learning
- AWS Cloud Practitioner Essentials
- Java — Mastering the Fundamentals
- Python Course for Beginners

## 💼 Experience

### Infosys Springboard — Virtual Internship (Dec 2025 – Feb 2026)
Worked on a digital banking fraud detection and transaction simulation project using Java, including transaction monitoring, fraud analysis and risk detection logic.

### Enmlitiz Technology, Salem — Web Development Internship
Worked on web development-related tasks and practical application development.

## 📊 What I'm Working On

- Full-stack web development
- Java programming
- MERN stack applications
- SQL and database concepts
- Data structures and problem solving
- AI-powered recruitment and developer tools

## 📈 GitHub Activity

<div align="center">

![Gokul's GitHub contribution graph](https://ghchart.rshah.org/2753d6/gokul27108)

![Gokul's GitHub stats](https://github-readme-stats.vercel.app/api?username=gokul27108&show_icons=true&theme=tokyonight&hide_border=true)
![Top languages](https://github-readme-stats.vercel.app/api/top-langs/?username=gokul27108&layout=compact&theme=tokyonight&hide_border=true)

</div>

## 📫 Connect With Me

- GitHub: [@gokul27108](https://github.com/gokul27108)
- LinkedIn: [Gokul M](https://www.linkedin.com/in/gokul-m-a4b08b314/)
- LeetCode: [gokul_5048](https://leetcode.com/u/gokul_5048/)
- Email: gokulmathiyalagan27@gmail.com

---

<div align="center">

### ⭐ Thanks for visiting my profile!

</div>
